/**
 * Atribuir +1 Ticket ao Agente
 * 
 * Autor: Jonathan Silva
 * Email: jonathan.silva@saipos.com
 * Data: 2024-09-17
 * Versão 3.0.0
 * Descrição:
 * Este aplicativo Zendesk atribui automaticamente o ticket mais antigo não atribuído da fila do grupo ao agente atual.
 */

var client;

document.addEventListener('DOMContentLoaded', function() {
    client = ZAFClient.init();

    // Obtenha o token OAuth
    client.get('currentUser').then(function(userData) {
        fetchTicketCountFromView();
        initializeButton();
    });
});

function fetchTicketCountFromView() {
    const viewId = '28426766099220'; // ID da fila Aguardando - N1

    client.request({
        url: `/api/v2/views/${viewId}/tickets.json`,
        type: 'GET',
        dataType: 'json'
    }).then(function(data) {
        console.log('Resposta da API:', data);
        if (data.tickets && data.tickets.length > 0) {
            var ticketCount = data.tickets.length;
            document.getElementById('ticket-count').textContent = 'Tickets aguardando N1📣:' + ticketCount;
        } else {
            document.getElementById('ticket-count').textContent = 'Nenhum ticket aguardando N1📣.';
        }
    }).catch(function(err) {
        console.error('Erro ao obter tickets da fila:', err);
        document.getElementById('ticket-count').textContent = 'Erro ao carregar a fila de tickets.';
    });
}

function initializeButton() {
    const button = document.getElementById('assign-ticket-button');
    if (button) {
        button.removeEventListener('click', handleButtonClick);
        button.addEventListener('click', handleButtonClick);
    }
}

function handleButtonClick() {
    assignOldestTicketFromView();
}

function assignOldestTicketFromView() {
    const viewId = '28426766099220'; // ID da fila definida

    client.invoke('notify', 'Buscando ticket mais antigo na fila...', 'notice');
    client.request({
        url: `/api/v2/views/${viewId}/tickets.json`,
        type: 'GET',
        dataType: 'json',
        headers: {
            "Authorization": `Bearer ${oauthToken}` // Autenticação com OAuth
        }
    }).then(function(data) {
        if (data.tickets && data.tickets.length > 0) {
            const oldestTicket = data.tickets[0];
            console.log("Ticket mais antigo encontrado:", oldestTicket);
            assignTicketToAgent(oldestTicket.id);
        } else {
            console.log("Nenhum ticket encontrado na fila.");
            client.invoke('notify', 'Nenhum ticket encontrado na fila.', 'error');
        }
    }).catch(function(error) {
        console.error("Erro ao buscar os tickets:", error);
        client.invoke('notify', 'Erro ao buscar tickets da fila.', 'error');
    });
}

function assignTicketToAgent(ticketId) {
    client.get('currentUser').then(function(userData) {
        const agentId = userData.currentUser.id;
        console.log("Atribuindo ticket ao agente ID:", agentId);

        client.request({
            url: `/api/v2/tickets/${ticketId}.json`,
            type: 'PUT',
            dataType: 'json',
            headers: {
                "Authorization": `Bearer ${oauthToken}` // Autenticação com OAuth
            },
            data: JSON.stringify({
                ticket: {
                    assignee_id: agentId
                }
            }),
            contentType: 'application/json'
        }).then(function(response) {
            console.log("Ticket atribuído com sucesso.");
            client.invoke('notify', `Ticket #${ticketId} atribuído com sucesso!`, 'notice');
        }).catch(function(error) {
            console.error("Erro ao atribuir o ticket:", error);
            client.invoke('notify', 'Erro ao atribuir o ticket.', 'error');
        });
    }).catch(function(error) {
        console.error("Erro ao obter o usuário atual:", error);
        client.invoke('notify', 'Erro ao obter o usuário atual.', 'error');
    });
}
